This is a simple game, in theory, this is a game that can go on endlessly. 
Missing functionalities: I'm missing a new type of reward to provide temporary double fire power. 
New functionalities: the heart reward that heal the player. 
Some problems/bugs: 
	- The menu can be select during the game and when it opened, the keyboard will not be able to control the jet. 
	- The hit box of the jet and rock is not perfectly fit with the image becuase there are some empty spaces in the image. 
	- Due to the new enemy type is based on a random number in java, sometimes the spawn of enemy might be werid.
	- Close the window won't pause the game
	- I got some problem when trying to add music into the game using vscode. 
 
Just play the "Hell" mode, the "Free" mode is super easy, basically built for 3-5 years old kids. 
only enemy jet will increase your score, the rock won't, if you left one enemy jet pass you, you will lose 1 life PLUS 100 in score, 
so if you think you can't shoot that jet, just use your body to destroy it :)
My highest record is 820